from tcrutils import console as k

k('test')
